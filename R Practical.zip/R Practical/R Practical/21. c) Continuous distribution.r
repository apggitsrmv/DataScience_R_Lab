#runif()
runif(15, min=1, max=3) 

#qunif() 
min <- 0
max <- 40
qunif(0.2, min = min, max = max)
plot(qunif)
#dunif()
x <- 5:10
dunif(x, min = 1, max = 20)
plot(dunif)
#punif()
min <- 0 
max <- 60
punif (15 , min =min , max = max)
plot(punif)