v <- c(7,12,28,3,41)
plot(v,type = "o")
v <- c(7,12,28,3,41)
plot(v,type = "o", col = "red", xlab = "Month", ylab = "Rain fall",
     main = "Rain fall chart")
v <- c(7,12,28,3,41)
t <- c(14,7,6,19,3)
x<-c(15,7,8,18,5)
plot(v,type = "o",col = "red", xlab = "Month", ylab = "Rain fall",
     main = "Rain fall chart")

lines(t, type = "o", col = "blue")
lines(x, type = "o", col = "green")
